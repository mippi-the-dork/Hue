# Hue 0.19.0 Release Candidate

Hue 0.19.0 is the feature-frozen release candidate for the first public Hue release.

This build does not introduce a new styling system. It consolidates the functionality validated through the 0.18 series and moves Hue into final regression and release-preparation testing.

## Current Feature Set

- Header Color, Header Text Color, Body Color, and Body Text Color overrides
- Instance, Category, and Global styling scopes
- Nested Blueprint Category inheritance
- Category rename persistence
- Multi-selection and batch editing
- Mixed-value reporting
- Batch Undo/Redo
- Effective-source labels in the Hue panel
- Right-click Hue menus
- Broad standard K2 node support
- Guarded support for specialized/native Blueprint node presentations
- Multi-editor and large-graph hardening

## Release Candidate Changes

- Feature set frozen for 1.0 validation
- Public README rewritten for release use
- Compatibility matrix updated for RC status
- Final release-candidate validation gate added
- Release checklist added
- FAB description draft added
- GitHub release copy prepared
- Repository description prepared
- Source audited for temporary debug logging, TODO/FIXME markers, and malformed UTF-8 BOMs

## Validation Focus

Before 1.0.0, this RC should be tested for:

- clean UE 5.8.3 compilation
- all four Hue channels across representative node families
- Instance / Category / Global precedence
- nested Category inheritance
- Category rename migration
- duplicate, copy/paste, save/reopen, compile, and reconstruction
- multi-select batch editing and Undo/Redo
- multiple Blueprint Editors and graph panels
- unsupported-node safety
- large-graph responsiveness

No new feature work is planned between this RC and 1.0.0 unless validation exposes a release-blocking issue.
