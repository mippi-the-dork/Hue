# Hue - FAB Description

Hue is an editor-only Blueprint styling plugin for Unreal Engine that adds persistent visual color overrides to compatible Blueprint nodes without changing Blueprint behavior.

Style a single node, a user-authored My Blueprint Category, or the same logical node identity project-wide. Hue keeps each visual channel independent, supports inheritance through nested Blueprint Categories, and preserves Unreal-owned controls on specialized nodes.

## Highlights

- Header Color, Header Text Color, Body Color, and Body Text Color
- Instance, Category, and Global styling scopes
- Nested My Blueprint Category inheritance
- Category rename persistence
- Multi-selection and batch editing across unrelated supported node types
- Mixed-value reporting
- One-step Undo/Redo for batch operations
- Effective-source labels showing where an inherited value comes from
- Right-click Hue workflow and dedicated Blueprint Editor panel
- Broad standard and specialized Blueprint node coverage
- Native class selectors, dynamic pins, exposed-on-spawn controls, and node-specific interactions remain Unreal-owned
- Unsupported node presentations are left untouched instead of receiving no-op styling controls
- Editor only, with no packaged-game runtime system
- No Unreal Engine source modifications

Hue is designed for developers who use color as part of Blueprint graph organization and want that visual language to scale beyond manually styling one node at a time.

**Compatibility:** Unreal Engine 5.8.0 - 5.8.3  
**Platform:** Windows 64-bit  
**Plugin Type:** Editor Only
