# Hue 0.19.1 Release Candidate Validation Plan

## 1. Build and Smoke Test

1. Replace the previous Hue plugin with Hue 0.19.1.
2. Close Unreal Editor before building.
3. Build the project Editor target.
4. Launch Unreal Editor.
5. Open `HueTest` and the Hue panel.

Expected: no crash, Hue panel follows supported selected nodes, and the right-click Hue submenu still appears on known-good nodes.

Use **Print String** and **Branch** as the first known-good controls.


## Release Candidate Exit Gate

Hue 0.19.1 can be promoted to 1.0.0 only when:

- the plugin compiles cleanly against the target Unreal Engine installation
- all known-good node families retain all four Hue channels
- unsupported nodes remain untouched and expose no no-op Hue controls
- Instance, Category, nested Category inheritance, and Global precedence remain correct
- Category rename migration passes, including Undo/Redo
- multi-selection and batch Undo/Redo pass
- duplicate, copy/paste, save/reopen, compile, and reconstruction pass
- multiple Blueprint Editors and graph panels remain independent and stable
- large-graph interaction shows no obvious Hue-specific stall or repeated compatibility probing
- context-menu and Hue-panel terminology/behavior agree
- no release-blocking crash, data-loss, or native-control regression remains

Do not add feature work during RC validation unless it is required to resolve a release blocker.

## 2. Performance and Multi-Editor Hardening

### Large Graph Smoke Test

1. Open a Blueprint graph containing several hundred supported nodes, or duplicate a mixed group until the graph is large enough to scroll and zoom continuously.
2. Keep the Hue panel open.
3. Pan, zoom, marquee-select, and multi-select nodes for at least a minute.
4. Change an Instance Body Color across a large selection and Undo once.

Expected:

- graph interaction remains responsive
- Hue does not cause visible periodic stalls while simply panning or zooming
- the batch edit updates the selection together
- one Undo restores the previous values

### Category Resolution Does Not Depend on Paint

1. Create `Attack`, `Attack|Weapons`, and `Attack|Weapons|Melee`.
2. Style `Attack` and confirm descendants inherit it.
3. Pan/zoom repeatedly without editing the Blueprint.
4. Rename `Attack` to `Combat`.

Expected:

- inheritance remains correct before the rename
- the rename migrates the stored Category rule when the Blueprint reports the change
- descendants continue inheriting under the renamed hierarchy
- no extra user action or graph repaint is required to trigger migration

### Two Blueprint Editors

1. Open two different Blueprint assets in separate Blueprint Editor windows.
2. Give each Blueprint different Instance and Category Hue rules.
3. Keep the Hue panel open in both editors and switch between them.
4. Edit Hue values in each window.

Expected:

- each panel follows only its own editor selection
- edits in one Blueprint do not change unrelated Instance or Category rules in the other
- Global rules still update matching identities project-wide

### Same Blueprint, Multiple Graph Panels

1. Open multiple graph tabs for the same Blueprint, such as Event Graph plus one or more functions.
2. If your editor layout allows the same graph/node to be represented in more than one panel, keep both visible.
3. Test known specialized/native nodes such as Create Widget and Spawn Actor from Class.
4. Compile the Blueprint and revisit both panels.

Expected:

- supported nodes remain Hue-capable in each visible presentation
- a failed compatibility probe on one exact widget does not permanently poison a different reconstructed widget
- compile/reconstruction allows a new widget presentation to be checked again
- native controls remain functional

### Rejected Custom Widget Cache

Use any K2/custom node that Hue correctly reports as unsupported. Leave it selected with the Hue panel open while interacting with the graph.

Expected: the node remains unsupported and untouched. Hue should not repeatedly mutate or partially decorate the widget, and other supported selected nodes remain editable.

## 3. Multi-Selection and Batch Editing

### Basic Instance Batch

Place these exact nodes in one Blueprint graph:

- **Print String**
- **Branch**
- **Sequence**
- **Create Widget**

Select all four.

Expected:

- the Hue panel reports four Hue-compatible selected nodes
- Instance reads `Instance (4 Nodes)`
- changing only **Body Color** changes all four nodes
- Header Color, Header Text Color, and Body Text Color remain unchanged

Press **Ctrl+Z** once.

Expected: the Body Color change is reverted on all four nodes in one Undo step.

Press **Ctrl+Y** once.

Expected: all four receive the batch color again in one Redo step.

### Mixed Values

1. Select only Print String and give its Instance Body Color one color.
2. Select only Branch and give its Instance Body Color a different color.
3. Select both nodes.

Expected: Instance > Body Color reports **Multiple Values**.

Choose a new Body Color while both remain selected.

Expected:

- both nodes receive the new color
- the state changes to **Override**
- one Undo restores the two different previous values

Now clear Body Color with both selected.

Expected: both Instance Body Color overrides are removed in one operation.

### Partial Unsupported Selection

Add a **Reroute Node** to the selection with Print String and Branch.

Expected:

- the panel reports two Hue-compatible nodes
- it also reports one unsupported selected node
- Hue edits affect Print String and Branch
- the Reroute Node remains untouched
- the unsupported node does not disable batch editing

### Category Deduplication

Create Blueprint functions:

```text
MovementA   Category = Movement
MovementB   Category = Movement
CombatA     Category = Combat
```

Place calls to all three in the same graph and select them.

Expected:

- Category scope reports **2 Categories**, not 3 nodes
- setting Category Body Color writes Movement once and Combat once
- both Movement calls receive the Movement rule
- Combat receives the Combat rule
- one Undo reverts the whole batch

Add a supported node with no applicable My Blueprint Category to the selection.

Expected: the Category section reports that node as ineligible and ignores it without blocking the two valid categories.

### Global Deduplication

Place:

- three **Print String** nodes
- two **Branch** nodes

Select all five.

Expected: Global scope reports **2 Targets**, because repeated global identities are deduplicated.

Set Global Header Color.

Expected:

- all Print String nodes using that identity update
- all Branch nodes using that identity update
- other matching usages elsewhere in the project also update
- the operation is one Undo step

### Right-Click Batch Editing

Keep several supported nodes selected and right-click one node that is part of the selection.

Expected:

- the Hue submenu operates on the full compatible selection
- Instance, Category, and Global labels show their batch target counts
- setting or clearing a channel affects the same targets as the Hue panel

Right-click a supported node that is not part of the previous selection.

Expected: Hue operates on the context node/current Unreal selection rather than accidentally editing the stale previous group.


## 4. Category Rename Persistence

### Basic Category Rename

1. Create two Blueprint functions, `AttackA` and `AttackB`.
2. Put both in the exact My Blueprint category `Combat`.
3. Place calls to both functions in the graph.
4. Give Category scope obvious values for all four Hue channels.
5. In My Blueprint, rename the category `Combat` to `Gameplay`.

Expected:

- both function calls retain the Category Hue appearance immediately
- the Hue panel now reports the Category as `Gameplay`
- the old `Combat` rule no longer acts as the active category rule
- save/reopen preserves the renamed category and its Hue settings

### Undo / Redo Rename

After the previous test:

1. Press **Ctrl+Z** once.
2. Confirm the category returns to `Combat`.
3. Confirm the Hue Category rule follows it back.
4. Press **Ctrl+Y** once.
5. Confirm `Gameplay` and the same Hue Category rule return together.

Expected: category rename and Hue behavior remain aligned through Undo/Redo without requiring a second Hue-specific Undo step.

### Nested Category Rename

Create members in:

```text
Combat|Weapons
Combat|Defense
```

Give at least one of those exact child categories a Category Hue override. Rename the parent category from `Combat` to `Gameplay`.

Expected: matching styled child categories follow the renamed prefix, for example `Combat|Weapons` becomes `Gameplay|Weapons` without losing Hue settings.

### Move Member Is Not Rename

1. Create `AttackA` and `AttackB` in `Combat`.
2. Give `Combat` a Category Hue override.
3. Move only `AttackA` into a different category named `Special`.

Expected:

- `AttackB` remains governed by the `Combat` Hue rule
- `AttackA` does not cause the `Combat` Hue rule to migrate to `Special`
- `Special` remains inherited/default unless separately styled

Repeat with a one-member styled category by moving its only member to a different category.

Expected: Hue does not guess that the move was a rename.

### Rename Into Existing Styled Category

1. Give `Combat` one set of Category Hue overrides.
2. Give `Gameplay` a different Category Hue override on at least one channel.
3. Rename `Combat` to `Gameplay` if Unreal permits the merge.

Expected: existing `Gameplay` channel values win conflicts; Hue only carries over channels that `Gameplay` did not already override.

## 5. Nested Category Inheritance

### Basic Parent Inheritance

1. Create or assign a Blueprint member to `Attack|Weapons`.
2. Give `Attack` obvious Hue overrides for all four channels.
3. Leave `Attack|Weapons` with no exact overrides.

Expected:

- the `Attack|Weapons` node inherits all four values from `Attack`
- the Category section still reports **Inherited**, not **Override**
- the inherited tooltip names `Attack` as the source
- no `Attack|Weapons` style entry needs to be created merely to display the inherited values

### Nearest Parent Wins

Create `Attack|Weapons|Melee`. Style `Attack` Red and `Attack|Weapons` Blue for the same channel. Leave `Attack|Weapons|Melee` unset.

Expected: `Attack|Weapons|Melee` resolves Blue from `Attack|Weapons`, not Red from `Attack`.

### Per-Channel Inheritance

Give `Attack` all four channel overrides. On `Attack|Weapons`, override only Body Color.

Expected: Body Color comes from `Attack|Weapons`; Header Color, Header Text Color, and Body Text Color continue to inherit from `Attack`.

### Clear Reveals Parent

With a child override active, clear only that channel on the child Category.

Expected: the child immediately returns to the nearest parent value for that channel. One Undo restores the child override.

### Parent Live Update

Change an inherited channel on `Attack`.

Expected: every descendant without a nearer override updates immediately after the single Hue edit.

### Global Fallback Below Category Hierarchy

Leave a channel unset on `Attack`, `Attack|Weapons`, and `Attack|Weapons|Melee`, then give the node's Global target a value for that channel.

Expected: the descendant uses Global. Adding an override to any parent Category immediately takes precedence over Global.

### Rename With Inheritance

Style `Attack`, create an unstyled child `Attack|Weapons`, then rename the parent hierarchy to `Combat`.

Expected: rename persistence migrates the exact stored rule and the renamed child continues inheriting from `Combat` without creating a copied child rule. Undo/Redo keeps the inheritance chain intact in both names.

## 6. Object Construction Sweep

### Construct Object from Class

Place **Construct Object from Class** with a usable Blueprintable UObject class.

Check:

- Header Color
- Header Text Color
- Body Color
- Body Text Color
- Class selector
- Outer pin if present
- exposed-on-spawn pins if the selected class provides them
- change the Class and verify pin reconstruction
- Undo/Redo
- compile
- duplicate
- copy/paste
- save/reopen

### Add Component by Class

In an Actor Blueprint place **Add Component by Class**. Use a concrete component class such as `Point Light Component` or `Static Mesh Component`.

Check:

- all four Hue channels
- Class selection
- Return Value typing
- attachment/transform-related pins remain usable
- change Class and verify reconstruction
- Undo/Redo
- compile
- duplicate
- copy/paste
- save/reopen

### Spawn Actor from Class

Use an Actor class with at least one exposed-on-spawn variable.

Check:

- all four Hue channels
- Class selector
- Spawn Transform
- Collision Handling Override
- exposed-on-spawn pins
- change Class and verify reconstruction
- compile, Undo/Redo, duplicate, copy/paste, save/reopen

### Create Widget

Use `WBP_HueTest` with at least one exposed-on-spawn variable.

Check:

- all four Hue channels
- Class selector
- Owning Player
- exposed-on-spawn pins
- change Class and verify reconstruction
- compile, Undo/Redo, duplicate, copy/paste, save/reopen

## 7. Add Pin Family Sweep

Hue 0.13.0 specifically changes this family. Test every exact node below.

### Sequence

- add at least two pins with the node's Add Pin button
- Undo once and confirm the last added pin disappears
- Redo and confirm it returns
- confirm Hue remains applied after each rebuild

### MultiGate

- add output pins
- verify Start Index, Is Random, and Loop remain normal
- Undo/Redo added pins
- compile and save/reopen

### Select

- place a normal **Select** node
- add options with Add Pin
- connect/change the Index type where applicable
- Undo/Redo added options
- verify type reconstruction and Hue remain correct

### Make Array

- add/remove entries
- change element type through connections
- Undo/Redo pin additions
- verify Hue and compilation

### Make Set

- add/remove entries
- change element type through connections
- Undo/Redo pin additions
- verify Hue and compilation

### Make Map

- add/remove key/value entries
- change key/value types through connections
- Undo/Redo pin additions
- verify Hue and compilation

Expected across this section: the Add Pin button disappears whenever the node reports that another pin cannot be added, matching native behavior.

Visual parity check: compare each Hue Add Pin row against the equivalent stock Unreal node with Hue disabled. The plus icon, text order, input/output side alignment, row spacing, and hover footprint should match Unreal's native presentation.

## 8. Switch and Control-Flow Sweep

Test exact nodes:

- **Switch on Int**
- **Switch on Enum**
- **Switch on String**
- **Switch on Name**
- **ForEachLoop**
- **ForEachLoopWithBreak**
- **Cast To Character** or another concrete Cast To node
- **Delay**

For each:

- all applicable Hue channels
- right-click Hue menu
- native pin behavior
- compile
- duplicate
- copy/paste
- save/reopen

For Switch nodes, add/remove cases where the node allows it and verify reconstruction.

## 9. Async Node Sweep

Place at least one project-available async Blueprint node that produces asynchronous execution outputs. If available, use **Async Load Asset** as the concrete test.

Check:

- Hue support is offered only if the visual actually changes
- all native async output pins remain present
- delegate/async output names are unchanged
- compile and save/reopen

If the async node owns a custom visual that Hue cannot safely map, expected behavior is **no Hue controls**, not a silent no-op.

## 10. Struct Sweep

Create `HueTestStruct` with:

```text
Health  : Float
Name    : String
Enabled : Boolean
```

Test exact nodes:

- **Make HueTestStruct**
- **Break HueTestStruct**
- **Set Members in HueTestStruct**

For Set Members, expose/hide member pins from the node's Details panel.

Check:

- Hue survives member-pin reconstruction
- default-value widgets remain native
- split/recombine behavior remains normal where available
- compile, Undo/Redo, duplicate, copy/paste, save/reopen

## 11. Compact and Container Regression

Test:

- Array Get
- Array Add
- Last Index
- Map Add
- Map Find
- Set Add
- Set Contains
- Get Game Instance Subsystem
- Get Local Player Subsystem
- Get World Subsystem
- Get Engine Subsystem

Expected: existing compact Hue behavior remains unchanged.

## 12. Specialized Regression

Recheck known native-specialized nodes:

- Create Event
- Spawn Actor from Class
- Material Parameter Collection Set Scalar Parameter Value
- Make HueTestStruct
- Copy, if exposed in the current Blueprint context

Expected: native controls remain functional and Hue does not disappear after native widget rebuilds.

## 13. Visual-State Regression

On representative standard, compact, Add Pin, and native-specialized nodes test:

- unselected
- selected
- hover
- zoomed in
- zoomed far out
- disabled node
- breakpoint present
- active breakpoint during PIE if practical
- compile warning
- compile error

Expected: Hue remains readable without hiding Unreal's debugging/error states.

## 14. Reconstruction and Persistence

For at least one node from each family:

- compile Blueprint
- modify a referenced class/struct so the node reconstructs
- rename the Blueprint asset
- duplicate node
- copy/paste in the same Blueprint
- copy/paste into another Blueprint
- save and close Blueprint
- reopen Blueprint
- restart Editor and reopen

Expected: Hue data follows its documented scope and no unsupported node suddenly gains a no-op Hue UI.

## 15. Unsupported Controls

### Reroute Node

Expected: no Hue panel support and no Hue right-click submenu.

### Documentation Node

Do not use for Hue testing. It remains intentionally unsupported and untouched.

### Unknown Custom K2 Node

If the project contains a third-party/custom K2 node with its own visual widget:

- if Hue finds a compatible standard header and body, Hue may attach automatically
- if not, Hue must leave it untouched and offer no Hue controls

The failure condition is a Hue UI that allows setting colors while the node does not visibly respond.

## 16. Scope Precedence

On a supported categorized Blueprint member node set different values for Global, Category, and Instance.

Expected:

```text
Instance > Exact Category > Nearest Parent Category > Higher Parent Categories > Global > Unreal Default
```


## 17. Visual and UX Polish

### Single-Selection Source Labels

Use one categorized Blueprint member node and configure different channels across Instance, exact Category, parent Category, Global, and Unreal Default.

Expected:

- an explicit value at the currently viewed scope reports `Override`
- Instance with no Instance override reports the effective Category name when Category supplies the channel
- Category with no exact override reports `Parent: <Category>` when a parent supplies the channel
- Instance or Category reports the applicable `Global Function`, `Global Event`, `Global Variable`, `Global Macro`, `Global Operator`, or `Global Node` label when Global supplies the channel
- a channel with no Hue override below the current scope reports `Unreal Default`
- hovering the source label explains the full inheritance path and what clearing will reveal

### Mixed Inherited Values

Select two supported nodes with no Instance override on Body Color. Give their Categories two different Body colors.

Expected: Instance Body Color reports `Multiple Values`, not merely `Inherited`.

Repeat with two nodes that inherit the same visible Body color.

Expected: Instance Body Color reports `Inherited`.

Now give one node an explicit Instance Body Color matching the other node's inherited visible color.

Expected: Instance Body Color still reports `Multiple Values` because explicit ownership differs even though the visible colors match.

### Panel Readability

Check the Hue panel at narrow and wide dock widths.

Expected:

- scope headers remain readable
- source labels do not obscure the color swatch or Clear button
- `Clear All Overrides` is visibly distinct from per-channel Clear
- the precedence reminder remains subdued and does not compete with the selected node name
- disabled/unavailable scopes remain understandable

### Context Menu Consistency

For one node and a multi-selection, compare panel terminology with the right-click Hue menu.

Expected: Instance, Category, Global identity labels, channel names, and clear behavior describe the same operation in both surfaces.
