# Hue 1.0.0

Hue 1.0.0 is the first public release of the Blueprint node styling utility for Unreal Engine.

Hue adds persistent editor-only color styling to compatible Blueprint nodes while preserving Unreal's native node behavior. Styles can be applied to a single node instance, inherited through My Blueprint Categories, or shared project-wide through Global identities.

## Highlights

- Style **Header Color**, **Header Text Color**, **Body Color**, and **Body Text Color** independently.
- Apply styles at **Instance**, **Category**, or **Global** scope.
- Use nested Category inheritance with nearest-parent precedence.
- Rename styled Categories without losing their Hue rules.
- Batch-edit unrelated supported nodes through multi-selection.
- See **Multiple Values** for genuinely mixed selections.
- Undo or redo a full batch edit in one transaction.
- See the effective source of inherited values directly in the Hue panel.
- Use Hue from either the dedicated Blueprint Editor panel or node right-click menu.
- Preserve native controls on specialized nodes such as **Create Widget**, **Spawn Actor from Class**, **Create Event**, **Make Struct**, and Material Parameter Collection nodes.
- Preserve native Add Pin behavior and presentation on compatible Add Pin node families.
- Leave unsupported custom presentations untouched instead of exposing styling controls that do nothing.

## Styling Precedence

Hue resolves each visual channel independently:

```text
Instance
> Exact Category
> Nearest Parent Category
> Higher Parent Categories
> Global
> Unreal Default
```

This allows a child Category or node instance to override one visual channel while continuing to inherit the others.

## Node Coverage

Hue supports the normal K2 presentation and a broad set of Blueprint node families, including standard function calls, Events, Variable Get/Set, Cast nodes, compact operators, Sequence and compatible Add Pin nodes, Select, MultiGate, Make Array/Set/Map, Switch nodes, Timeline, Format Text, collapsed graphs, construction nodes, and guarded native-specialized presentations.

Reroute and Documentation nodes remain intentionally unsupported because Hue's four styling channels do not map safely or meaningfully to their presentation.

## Editor-Only Design

Hue does not change Blueprint execution, add runtime gameplay systems, affect packaged-game rendering, or require Unreal Engine source modifications.

## Compatibility

- **Hue:** 1.0.0
- **Unreal Engine:** 5.8.0 - 5.8.3
- **Primary validation:** 5.8.3
- **Platform:** Windows 64-bit
- **Plugin type:** Editor Only

The 1.0.0 source is promoted directly from the validated 0.19.1 release candidate. No new feature behavior was introduced during the final release promotion.
