# Hue Specialized Blueprint Node Audit

## 1.0.0 Release Status

Hue 1.0.0 promotes the validated 0.19.1 rendering architecture without adding another presentation route. Standard, dedicated, native-specialized, pin-assisted, and displayed-widget compatibility paths are the supported 1.0 foundation. The final 0.19.1 fix restored native Add Pin row padding and side alignment in Hue-owned Add Pin wrappers.


Hue's rule is:

> Every visually meaningful Blueprint node should support Hue wherever technically safe.

Native behavior takes priority over visual coverage.

## Current Coverage

| Unreal presentation path | Current status | Approach |
| --- | --- | --- |
| `SGraphNodeK2Default`, standard | Supported | Hue default wrapper |
| `SGraphNodeK2Base`, compact | Supported | Generic compact Hue binding |
| `SGraphNodeK2Event` | Supported | Dedicated Hue event wrapper |
| Add Pin / Sequence-style | Supported | Hue compatibility wrapper with native transaction + visibility behavior |
| `SGraphNodeK2Var` | Supported | Dedicated native-derived variable wrapper |
| `SGraphNodeK2Composite` | Supported | Dedicated native-derived composite wrapper |
| `SGraphNodeSwitchStatement` | Supported | Switch compatibility wrapper |
| `SGraphNodePromotableOperator` | Supported | Operator compatibility wrapper |
| `SGraphNodeK2Timeline` | Supported | Timeline compatibility wrapper |
| `SGraphNodeFormatText` | Supported | Format Text compatibility wrapper |
| `SGraphNodeSpawnActor` | Native bridge | Unreal builds native widget, Hue decorates safe visual layers |
| `SGraphNodeSpawnActorFromClass` | Native bridge | Unreal builds native widget, Hue decorates safe visual layers |
| `SGraphNodeK2CreateDelegate` | Native bridge | Preserves native Create Event function-selection UI |
| `SGraphNodeCallParameterCollectionFunction` | Native bridge | Preserves native parameter-collection UI |
| `SGraphNodeMakeStruct` | Native bridge | Preserves native struct presentation |
| `SGraphNodeK2Copy` | Native bridge | Preserves native Copy presentation |
| `SGraphNodeKnot` | Intentionally native | Current Hue channels do not map meaningfully |
| `SGraphNodeDocumentation` | Intentionally unsupported | Hue never intercepts it |
| `UK2Node_CreateWidget` node-owned visual | Supported | Construction hook plus validated displayed-widget decoration |
| Other node-owned `CreateVisualWidget()` | Compatible fallback | Supported only if Hue confirms standard header + body surfaces |

## Multi-Selection Note


Hue 0.17.0 does not add a new rendering route. It hardens the existing routes for large graphs and multiple graph panels. Category rename migration is now driven by Blueprint change/compile notifications instead of live color resolution, and failed native/custom compatibility probes are remembered per displayed Slate widget so the same rejected presentation is not recursively scanned every query. A reconstructed or different widget can still be tested again.

Hue 0.16.0 does not add another Slate presentation route for Category inheritance. The hierarchy is resolved above the renderer. Hue 0.14.1 also did not add another Slate presentation route for batch editing. Batch editing operates above the renderer: it resolves the selected supported nodes into unique Instance, Category, or Global targets, writes the requested channel once per target, and performs one final visual invalidation. Unsupported selected nodes never enter the mutation set.

## Add Pin Compatibility

Unreal routes nodes implementing `IK2Node_AddPinInterface` through its Sequence-style graph presentation. This includes Sequence, MultiGate, Select, Make Array, Make Set, Make Map, and other compatible Add Pin nodes.

Hue cannot rely on the private engine Slate implementation in every installed-engine layout, so it supplies its own compatible wrapper. Hue 0.13.0 restores two pieces of native behavior that wrapper must preserve:

1. Add Pin runs inside an editor transaction, so Undo/Redo treats the operation normally.
2. The Add Pin button follows `CanAddPin()` and collapses when no additional pin may be created.

The node remains responsible for the actual pin creation, naming, typing, and reconstruction.

## Native-Specialized Bridge

Some of Unreal's specialized Slate node classes are private to GraphEditor and cannot be safely inherited by a distributable plugin through normal public include paths.

Hue handles selected native-specialized families without including private Engine headers:

1. Hue detects the known specialized node UObject class.
2. Hue marks the node provisionally so the Hue exec-pin widget can participate during native construction.
3. Hue temporarily declines its own visual factory.
4. Unreal's public `FNodeFactory::CreateNodeWidget()` builds the stock specialized widget.
5. Hue scans the completed widget for compatible standard header and body surfaces.
6. If both are present, Hue binds its visual attributes.
7. If either is missing, Hue retracts the support claim and the Hue exec pin falls back to native color.

This keeps specialized controls Unreal-owned instead of recreating them from private implementation details.

## Node-Owned Visual Fallback

`UEdGraphNode::CreateVisualWidget()` runs before registered graph-node factories. A K2 node can therefore bypass Hue completely by returning its own native widget.

Create Widget remains explicitly recognized during pin construction because Hue needs that early hook to provide its compatible exec-pin widget.

Hue 0.13.0 also adds a general displayed-widget fallback:

1. An unconfirmed K2 node is selected, right-clicked, or otherwise queried for Hue support.
2. Hue looks at Unreal's already displayed `SGraphNode` through the public deprecated weak pointer.
3. Hue first scans the tree without changing it.
4. Hue requires both a recognizable standard header surface and body surface.
5. Only after that validation does Hue attach its color attributes and mark the live node supported.
6. If validation fails, Hue leaves the native widget untouched and exposes no Hue controls.

This is intentionally conservative. A custom renderer with a nonstandard layout remains a dedicated compatibility task rather than receiving a false-positive support claim.

## Confirmed Support Registry

Hue does not equate "is a K2 node" with "Hue visibly supports this node."

The style resolver tracks live nodes for which Hue has established a presentation path. The Hue panel, context menu, style mutation commands, and execution-pin tint all consult that confirmed registry.

A node can become confirmed through:

- a Hue-owned wrapper,
- a validated native-specialized bridge,
- or a validated node-owned displayed-widget fallback.

## Construction-Family Audit

The 0.13.0 sweep separates object-construction behavior from Slate presentation:

- `UK2Node_ConstructObjectFromClass` uses the normal K2 presentation. Class changes and exposed-on-spawn pins are node behavior, so Hue's default wrapper preserves them.
- `UK2Node_AddComponentByClass` derives from `UK2Node_ConstructObjectFromClass` and uses the same broad path unless the engine supplies a node-owned visual.
- `UK2Node_SpawnActorFromClass` has a dedicated native specialized renderer and remains on Hue's native bridge.
- `UK2Node_CreateWidget` owns its visual path and remains on the node-owned bridge/fallback.

See `Compatibility-Matrix.md` and `Release-Validation-Plan.md` for the exact validation set.

## Acceptance Rule

A family is not considered release-validated merely because color appears. It must retain the native behavior relevant to that node, including selectors, pin reconstruction, type promotion, exposed-on-spawn pins, default-value widgets, Undo/Redo, compilation, save/reopen, duplication, copy/paste, and node-specific navigation.

If any compatibility path breaks those interactions, that family returns to Pending and should receive a dedicated implementation instead.

## Menu Registration

Hue extends the expected Blueprint node ToolMenu names even before Unreal has registered them. `UToolMenus::ExtendMenu()` supports this late-registration case, so Hue can attach to class-specific menus that Unreal creates lazily. Hue also refreshes after Blueprint editor initialization, rescans when modules load, and targets the K2 parent context menu when available.
