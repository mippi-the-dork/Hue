# Hue 1.0.0 Compatibility Matrix

## Release Rule

Hue 1.0.0 ships the feature-frozen rendering and compatibility architecture validated in 0.19.1. A family is considered supported only when Hue visibly styles it while preserving the native Unreal interaction that makes that node useful.


This matrix separates **implementation path** from **release validation**. Hue 1.0.0 targets Unreal Engine 5.8.0 - 5.8.3 on Windows 64-bit, with primary validation on UE 5.8.3.

## Core Presentation Families

| Node / family | UE presentation route | Hue route | 1.0.0 status |
| --- | --- | --- | --- |
| Print String / ordinary calls | Standard K2 | Hue default wrapper | Implemented, regression test |
| Branch | Standard K2 | Hue default wrapper | Implemented, regression test |
| Cast To | Standard K2 | Hue default wrapper | Implemented, sweep target |
| Delay / latent call | Standard K2 call | Hue default wrapper | Implemented, sweep target |
| Async K2 nodes using normal K2 visual | Standard K2 | Hue default wrapper | Implemented, sweep target |
| Variable Get / Set | Variable presentation | Dedicated Hue variable wrapper | Implemented, regression test |
| Break Struct | Variable-style K2 presentation | Dedicated Hue variable wrapper through `DrawNodeAsVariable()` | Implemented, sweep target |
| Switch on Int / Enum / String / Name | Switch presentation | Dedicated Hue switch wrapper | Implemented, sweep target |
| Add / Multiply promotable operator | Promotable operator | Dedicated Hue operator wrapper | Implemented, regression test |
| Sequence | Add Pin presentation | Hue Add Pin wrapper | 0.13 transaction/visibility fix |
| MultiGate | Add Pin presentation | Hue Add Pin wrapper | 0.13 sweep target |
| Select | Add Pin presentation | Hue Add Pin wrapper | 0.13 sweep target |
| Make Array / Set / Map | Add Pin presentation | Hue Add Pin wrapper | 0.13 sweep target |
| ForEachLoop / ForEachLoopWithBreak | Macro instance / standard K2 | Hue default wrapper | Implemented, sweep target |
| Timeline | Timeline presentation | Dedicated Hue timeline wrapper | Implemented, regression test |
| Format Text | Specialized format presentation | Dedicated Hue format wrapper | Implemented, regression test |
| Collapsed Graph | Composite presentation | Dedicated Hue composite wrapper | Implemented, regression test |

## Construction Nodes

| Exact node | K2 class / behavior | Hue route | What must remain native |
| --- | --- | --- | --- |
| Construct Object from Class | `UK2Node_ConstructObjectFromClass` | Standard Hue K2 wrapper | Class pin, Outer, exposed-on-spawn pins, reconstruction |
| Add Component by Class | derives from `UK2Node_ConstructObjectFromClass` | Standard Hue K2 wrapper unless engine supplies a node-owned visual | Class pin, transform/attachment controls, exposed-on-spawn pins, reconstruction |
| Spawn Actor from Class | `UK2Node_SpawnActorFromClass` | Native-specialized bridge | Class selector, transform, collision handling, exposed-on-spawn pins |
| Create Widget | node-owned native visual | Self-visual hook plus validated native fallback | Class selector, Owning Player, exposed-on-spawn pins, reconstruction |

## Struct Nodes

| Exact node | Hue route | Notes |
| --- | --- | --- |
| Make <Struct> | Native-specialized bridge | Preserves native struct renderer |
| Break <Struct> | Variable-style Hue wrapper | `UK2Node_BreakStruct` draws as variable |
| Set Members in <Struct> | Standard/variable K2 path selected by Unreal | Must preserve member visibility and reconstruction |

## Native-Specialized Bridge

These families let Unreal create its own renderer and are decorated afterward:

- Create Event / Create Delegate
- Spawn Actor
- Spawn Actor from Class
- Material Parameter Collection function nodes
- Make Struct
- Copy

0.13.0 changed support confirmation for this path. Hue marks the node provisionally so its execution pin can be constructed, then retracts support if the completed native widget does not expose both a compatible header and body surface.

## Node-Owned Visual Fallback

A node can return its own `SGraphNode` from `CreateVisualWidget()` and therefore bypass Hue's registered node factory entirely.

0.13.0 no longer assumed only Create Widget can do this. When Hue is asked whether an unconfirmed K2 node is supported, it can inspect the already-displayed native widget. The scan is non-destructive. Hue only attaches if both standard GraphEditor surfaces are found.

This fallback is intentionally conservative:

- compatible standard native visual -> attach and support
- custom visual without recognizable header/body -> untouched and unsupported
- Reroute/Knot -> intentionally unsupported
- Documentation -> intentionally unsupported

## Multi-Selection Editing

Hue 0.16.0 retains scope-aware batch editing across the same confirmed visual support set.

| Batch scope | Target identity | Deduplication |
| --- | --- | --- |
| Instance | Owning Blueprint + NodeGuid | one write per selected node |
| Category | Defining Blueprint + exact My Blueprint Category | repeated nodes in the same Category are written once |
| Global | Hue global identity key | repeated calls/usages of the same global identity are written once |

Batch UI behavior:

- supported and unsupported selected nodes can coexist
- unsupported nodes are counted and ignored
- mixed explicit values or explicit/inherited combinations report `Multiple Values`
- setting one channel changes only that channel
- one batch action creates one Unreal transaction
- one batch action performs one final Slate invalidation
- Category and Global sections report unique target counts rather than raw selected-node counts
- right-click Hue actions use the compatible current selection when the context node belongs to that selection

Global settings are now marked transactional before Hue edits them. `UHueSettings::PostEditUndo()` persists the restored config state so batch Global changes participate in Undo/Redo.




## Panel and Effective-Source UX

| Case | 1.0.0 behavior |
|---|---|
| single explicit scope value | reports `Override` |
| Instance inherits Category | reports `Category: <effective category>` |
| Category inherits parent | reports `Parent: <nearest styled parent>` |
| Instance/Category falls through to Global | reports the applicable Global identity label |
| no lower Hue source exists | reports `Unreal Default` |
| batch targets all inherit same visible value | reports `Inherited` |
| batch targets inherit different visible values | reports `Multiple Values` |
| batch mixes explicit and inherited ownership | reports `Multiple Values`, even when visible colors happen to match |
| clear explicit child/category value | reveals the next lower-precedence source immediately |

The source display is editor-only presentation logic. Hue 1.0.0 does not change the serialized Instance, Category, or Global style maps established by the validated release candidate.

## Performance and Multi-Editor Behavior

| Case | 0.17.0 behavior |
|---|---|
| Ordinary Hue color lookup | Lookup-only. Does not run Category rename/member fingerprint scans. |
| Blueprint change | Event-driven Category tracking refresh and rename migration. |
| Blueprint compile/reconstruction | Clears rejected custom-widget probes for that Blueprint so reconstructed presentations can be tested again. |
| Repeated unsupported custom widget query | Negative compatibility result is cached for that exact displayed widget. |
| Same node shown with a different widget | The new widget can be probed independently. |
| Multiple editor modes/windows for one Blueprint | Blueprint change delegates are registered once per Blueprint asset. |
| Hue batch edit | One transaction and one final visual invalidation remain unchanged. |

## Category Rename Persistence

Hue 0.15.0 adds editor-session category rename tracking without changing the serialized Category style map format. Existing Category styles remain keyed by exact My Blueprint category text, but Hue tracks the previous category structure while a Blueprint is being edited and migrates the rule when Unreal performs a category rename.

| Case | 0.15.0 behavior |
| --- | --- |
| Exact category rename | migrate the full Category Hue rule to the new category name |
| Parent/nested category rename | migrate matching styled descendant prefixes when the rename relationship is observable |
| Rename Undo/Redo | rule follows the category name in either direction |
| Move one member to another category | do not migrate the old Category Hue rule |
| Rename into existing styled category | destination channel overrides win; missing destination channels inherit from the migrated rule |

## Nested Category Inheritance

Hue 0.16.0 keeps Category styles stored on exact My Blueprint category keys, but color resolution now walks the category hierarchy per channel. No parent value is copied into a child rule.

| Case | 0.16.0 behavior |
|---|---|
| exact child override exists | exact child value wins |
| exact child channel unset | nearest parent with that channel wins |
| nearest parent channel unset | continue walking toward the root |
| no Category in chain has channel | fall through to Global, then Unreal Default |
| child overrides only one channel | other channels continue inheriting independently |
| clear child override | inherited parent value is revealed immediately |
| parent value changes | all descendants without nearer overrides update dynamically |
| parent category renamed | existing rename migration moves stored exact rules; inheritance follows the renamed hierarchy |

Effective precedence: `Instance > Exact Category > Nearest Parent Category > Higher Parent Categories > Global > Unreal Default`.
| Existing 0.14.1 data | compatible without serialized schema conversion |

The primary rename signal is Unreal's Blueprint category sort-name replacement. For Blueprints where that list does not expose enough information, Hue can additionally compare the stable members that previously composed a styled category. The fallback requires multiple matching members so a single-member move is not misclassified as a rename.

## Acceptance Criteria

A node family only moves to release-validated when all applicable items pass:

- all four Hue channels visibly behave as intended
- right-click Hue menu appears only when styling works
- native selectors and value controls still work
- dynamic/additional pins still work
- Undo/Redo still works
- compile succeeds
- Blueprint reconstruction succeeds
- duplicate works
- copy/paste works
- save/reopen preserves Hue state
- selection, hover, breakpoint, warning, and error visuals remain understandable
- node-specific navigation or interaction remains native
- multi-selection edits are one Undo/Redo transaction and do not touch unsupported selected nodes
