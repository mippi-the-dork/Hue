# Hue 0.19.1 Release Candidate Checklist

## Build

- [ ] Clean Development Editor / Win64 build on Unreal Engine 5.8.3
- [ ] Unreal Header Tool completes without Hue errors
- [ ] Editor launches with Hue enabled
- [ ] No Hue startup crash or module-load warning

## Core Styling

- [ ] Header Color
- [ ] Header Text Color
- [ ] Body Color
- [ ] Body Text Color
- [ ] Clear one channel
- [ ] Clear All Overrides
- [ ] Right-click Hue menu
- [ ] Hue panel

## Scope and Persistence

- [ ] Instance > Category > Global > Unreal Default
- [ ] Exact Category > nearest parent Category > higher parent Categories
- [ ] Category rename preserves settings
- [ ] Nested Category rename preserves descendant behavior
- [ ] Moving one member does not migrate an unrelated Category rule
- [ ] Duplicate
- [ ] Copy/paste in same Blueprint
- [ ] Copy/paste to another Blueprint
- [ ] Save/reopen
- [ ] Editor restart
- [ ] Blueprint rename/move
- [ ] Compile/reinstance

## Multi-Selection

- [ ] Unrelated node types batch-edit together
- [ ] Mixed values display correctly
- [ ] Unsupported selected nodes are ignored
- [ ] Unique Category target count is correct
- [ ] Unique Global target count is correct
- [ ] One Undo reverses one batch operation
- [ ] One Redo reapplies one batch operation

## Native Behavior

- [ ] Create Widget class picker and exposed-on-spawn pins
- [ ] Spawn Actor from Class controls
- [ ] Create Event / Create Delegate selectors
- [ ] Add Pin nodes and Undo/Redo
- [ ] Switch nodes
- [ ] Timeline
- [ ] Format Text
- [ ] Make Struct
- [ ] Material Parameter Collection nodes
- [ ] Copy node when available

## Safety

- [ ] Reroute Node remains unsupported
- [ ] Documentation Node remains unsupported
- [ ] Unknown incompatible custom widget remains untouched
- [ ] Breakpoint visuals remain readable
- [ ] Compile warning/error visuals remain readable
- [ ] Selection and hover remain readable

## Stress and Multi-Editor

- [ ] Large graph pan/zoom/select has no obvious Hue-specific stall
- [ ] Two Blueprint Editors remain independent
- [ ] Multiple graph tabs remain correct
- [ ] Compile/reconstruction allows valid custom/native widgets to reattach

## Release Materials

- [x] Public-style README
- [x] Compatibility matrix
- [x] Release candidate validation plan
- [x] FAB description draft
- [x] GitHub release notes draft
- [x] Repository description draft
- [ ] Final screenshots / GIFs, if used
- [ ] Final 1.0.0 version bump after RC passes
